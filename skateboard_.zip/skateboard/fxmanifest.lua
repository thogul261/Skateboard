fx_version 'cerulean'
game 'gta5'

author 'Red | Sceetzy'
description 'Realistic Skateboarding'
version '1.0.0''

shared_scripts {
    'config.lua',
}

server_script 'server/server.lua'
client_script 'client/client.lua' 