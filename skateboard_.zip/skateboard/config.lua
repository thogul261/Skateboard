Config = {} 
Config.MaxSpeedKmh = 190
Config.maxJumpHeight = 5.0
Config.LoseConnectionDistance = 100.0